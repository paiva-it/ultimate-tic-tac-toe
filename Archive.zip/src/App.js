import './App.css';

import Jogo from './components/jogo/Jogo';

function App() {
	return (
		<div className='app'>
			<Jogo />
		</div>
	);
}

export default App;
